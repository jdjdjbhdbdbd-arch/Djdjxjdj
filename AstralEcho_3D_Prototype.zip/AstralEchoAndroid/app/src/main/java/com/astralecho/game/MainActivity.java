package com.astralecho.game;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.view.View;
import android.graphics.Color;
public class MainActivity extends Activity {
 @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.rgb(9,13,27));getWindow().setNavigationBarColor(Color.rgb(9,13,27));WebView w=new WebView(this);w.setBackgroundColor(Color.rgb(9,13,27));WebSettings s=w.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setLoadsImagesAutomatically(true);w.setOverScrollMode(View.OVER_SCROLL_NEVER);setContentView(w);w.loadUrl("file:///android_asset/index.html");}
 @Override public void onBackPressed(){super.onBackPressed();}
}