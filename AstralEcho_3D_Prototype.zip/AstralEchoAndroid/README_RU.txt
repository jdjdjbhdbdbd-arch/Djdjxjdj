ASTRAL ECHO — Android Studio project
1. Установи Android Studio на компьютер.
2. Распакуй архив.
3. Открой папку AstralEchoAndroid через File > Open.
4. Дождись Gradle Sync (нужен интернет для загрузки Android Gradle Plugin и SDK 35).
5. Подключи Android-телефон с включённой отладкой USB или выбери эмулятор.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).
7. APK будет в app/build/outputs/apk/debug/app-debug.apk

Приложение работает офлайн, призывы симулируются локально, прогресс хранится в WebView localStorage.
Механика: 5★ базовый шанс 0,6%, мягкий гарант с 74-й попытки, жёсткий гарант 90, 50/50 и гарантия Аэлии после проигрыша. Остальные выпадения — 3★ оружие.
Для создания APK требуется Android Studio/Android SDK; в среде сборки этой сессии SDK не установлен.

СБОРКА БЕЗ КОМПЬЮТЕРА (через GitHub Actions):
1. На телефоне открой github.com и войди/создай аккаунт.
2. Нажми + > New repository. Название: AstralEcho. Сделай Public или Private, затем Create repository.
3. На странице репозитория нажми Add file > Upload files.
4. Распакуй ZIP на телефоне и загрузи ВСЁ содержимое папки AstralEchoAndroid, включая скрытую папку .github (если файловый менеджер скрывает её, используй ZIP/браузерный способ загрузки или включи показ скрытых файлов).
5. Нажми Commit changes.
6. Открой вкладку Actions, выбери Build Astral Echo APK и нажми Run workflow.
7. После завершения открой успешный запуск workflow, внизу Artifacts скачай AstralEcho-debug-apk.zip.
8. Распакуй его — внутри будет app-debug.apk. Нажми APK и установи. Возможно, Android попросит разрешить установку из этого источника.

Сборка выполняется на серверах GitHub; готовый APK появится как артефакт workflow. Для этого способа нужен аккаунт GitHub и интернет на телефоне.
